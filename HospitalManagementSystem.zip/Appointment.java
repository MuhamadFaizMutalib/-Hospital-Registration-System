public class Appointment {
    private String date;
    private String time;

    public Appointment(String d, String t){
        date = d;
        time = t;
    }

    public String getDate(){return date;}
    public String getTime(){return time;}

    public void setDate(String date){}
    public void setTime(String time){}

    public void displayAppoinment(){
        
    }
}
