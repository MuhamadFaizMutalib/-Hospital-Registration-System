import java.util.ArrayList;

public class Hospital {
    private String HospName;
    private Doctor doc;
    private ArrayList<Room> rooms;

    public Hospital(String hN){
        HospName = hN;


    }

    public String getHospName(){return HospName;}
    public ArrayList<Room> getRoom(){

    }

    public void addRoom(Room r){

    }

    public void assignPatient(Patient p){

    }
}
