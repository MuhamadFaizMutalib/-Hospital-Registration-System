public class HospitalManagementSystem{
    public static void main(String[]args) {
        
    }
}